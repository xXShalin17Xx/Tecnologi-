<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . "/HTML/inicio/config.php";

header("Content-Type: application/json");

if (!isset($_SESSION['id_usuario'])) {
  http_response_code(403);
  echo json_encode([]);
  exit;
}

$usuario_id = $_SESSION['id_usuario'] ?? null;
$receptorId = isset($_GET['receptor_id']) ? intval($_GET['receptor_id']) : 0;

if ($receptorId <= 0 || $receptorId === $idUsuario) {
  echo json_encode([]);
  exit;
}

$stmt = $conn->prepare("
  SELECT emisor_id, contenido, fecha
    FROM mensajes
   WHERE (emisor_id = ? AND receptor_id = ?)
      OR (emisor_id = ? AND receptor_id = ?)
ORDER BY fecha ASC
");
$stmt->bind_param("iiii", $idUsuario, $receptorId, $receptorId, $idUsuario);
$stmt->execute();
$result = $stmt->get_result();

$mensajes = [];
while ($row = $result->fetch_assoc()) {
  $mensajes[] = [
    'autor' => ($row['emisor_id'] == $idUsuario) ? 'Tú' : 'Ellx',
    'contenido' => htmlspecialchars($row['contenido']),
    'hora' => date("H:i", strtotime($row['fecha'])),
    'esPropio' => ($row['emisor_id'] == $idUsuario)
  ];
}

echo json_encode($mensajes);
$stmt->close();