<?php
session_start();
header("Content-Type: text/html; charset=UTF-8");

$emisor_id = $_SESSION['id_usuario'] ?? null;
if (!$emisor_id) {
  http_response_code(401);
  echo "❌ Sesión no iniciada.";
  exit;
}

$input = json_decode(file_get_contents("php://input"), true);
$mensaje = trim($input["mensaje"] ?? "");
$receptor_id = intval($input["receptor_id"] ?? 0);

if ($mensaje === "" || !$receptor_id) {
  http_response_code(400);
  echo "❌ Datos inválidos.";
  exit;
}

require_once __DIR__ . "/../inicio/config.php";

$stmt = $conn->prepare("
  INSERT INTO mensajes (emisor_id, receptor_id, contenido, fecha)
  VALUES (?, ?, ?, NOW())
");

if (!$stmt) {
  http_response_code(500);
  echo "❌ Error en prepare: " . $conn->error;
  exit;
}

$stmt->bind_param("iis", $emisor_id, $receptor_id, $mensaje);
if (!$stmt->execute()) {
  http_response_code(500);
  echo "❌ Error en execute: " . $stmt->error;
  exit;
}

$hora = date("H:i");
echo "
  <div class='mensaje enviado'>
    <strong>Tú:</strong> " . htmlspecialchars($mensaje) . "
    <span class='hora'>$hora</span>
  </div>
";

$stmt->close();
$conn->close();
?>