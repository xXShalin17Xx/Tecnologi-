<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/../inicio/config.php";

if (!isset($_SESSION['id'])) {
    header("Location: ../login/index.php");
    exit();
}

$usuario_id = $_SESSION['id_usuario'] ?? null;
$nombreUsuario = $_SESSION['nombre'];

$usuarios = $conn->query("
    SELECT id, nombre
      FROM usuarios
     WHERE id != $idUsuario
  ORDER BY nombre ASC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Usuarios disponibles para chatear</title>
  <link rel="stylesheet" href="chat.css">
</head>
<body>
  <h2>Usuarios disponibles para chatear</h2>
  <ul class="lista-chat">
  <?php while ($u = $usuarios->fetch_assoc()): ?>
    <li>
      <strong><?= htmlspecialchars($u['nombre']) ?></strong>
      <a href="chat.php?receptor_id=<?= $u['id'] ?>">
        <button>💬 Chatear con <?= htmlspecialchars($u['nombre']) ?></button>
      </a>
    </li>
  <?php endwhile; ?>
  </ul>
</body>
</html>