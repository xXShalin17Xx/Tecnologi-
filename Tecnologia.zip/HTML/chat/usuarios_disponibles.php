<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/../inicio/config.php";

if (!isset($_SESSION['id'])) {
    header("Location: ../inicio/index.php");
    exit();
}

$idUsuario = $_SESSION['id'];
$nombreUsuario = $_SESSION['nombre'];

$usuarios = $conn->query("
    SELECT id, nombre
      FROM usuarios
     WHERE id != $idUsuario
  ORDER BY nombre ASC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Seleccionar usuario para chatear</title>
  <link rel="stylesheet" href="chat.css">
</head>
<body>
  <h2>Usuarios disponibles para chatear</h2>
  <ul class="lista-chat">
    <?php while ($u = $usuarios->fetch_assoc()): ?>
      <li>
        <strong><?= htmlspecialchars($u['nombre']) ?></strong>
        <a href="chat.php?receptor_id=<?= $u['id'] ?>&receptor_nombre=<?= urlencode($u['nombre']) ?>">
          <button>💬 Iniciar chat</button>
        </a>
      </li>
    <?php endwhile; ?>
  </ul>
</body>
</html>