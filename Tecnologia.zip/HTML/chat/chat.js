function iniciarChat() {
  const form = document.getElementById("chat-form");
  const input = document.getElementById("chat-input");
  const messages = document.getElementById("chat-messages");
  const receptorInput = document.getElementById("receptor-id");

  if (!form || !input || !messages || !receptorInput) {
    console.warn("⚠️ Elementos del DOM no encontrados o receptor inválido en chat.js");
    return;
  }

  const receptorId = receptorInput.value;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const mensaje = input.value.trim();
    if (mensaje === "") return;

    try {
      const res = await fetch("/HTML/chat/enviar_mensaje.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mensaje, receptor_id: receptorId }),
      });

      if (!res.ok) throw new Error("Error al enviar el mensaje");

      const nuevoMensaje = await res.text();
      const temp = document.createElement("div");
      temp.innerHTML = nuevoMensaje;
      messages.appendChild(temp.firstElementChild);

      input.value = "";
      messages.scrollTop = messages.scrollHeight;
    } catch (err) {
      console.error("❌ Error en envío de mensaje:", err);
    }
  });

  setInterval(async () => {
  try {
    const res = await fetch(`/HTML/chat/obtener_mensajes.php?receptor_id=${receptorId}`);
    if (!res.ok) throw new Error("Error al obtener mensajes");

    const nuevosMensajes = await res.text();
    messages.innerHTML = nuevosMensajes;
    messages.scrollTop = messages.scrollHeight;
  } catch (err) {
    console.error("❌ Error al actualizar mensajes:", err);
  }
}, 5000);
}