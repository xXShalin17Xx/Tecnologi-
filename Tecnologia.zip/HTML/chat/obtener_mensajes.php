<?php

session_start();
header("Content-Type: text/html; charset=UTF-8");

$emisor_id = $_SESSION['id_usuario'] ?? null;
if (!$emisor_id) {
  http_response_code(401);
  echo "❌ Sesión no iniciada.";
  exit;
}

$receptor_id = isset($_GET["receptor_id"]) ? intval($_GET["receptor_id"]) : 0;
if (!$receptor_id) {
  http_response_code(400);
  echo "❌ Receptor inválido.";
  exit;
}

$conexion = new mysqli("localhost", "root", "", "tecnologia");
if ($conexion->connect_error) {
  http_response_code(500);
  echo "❌ Error de conexión.";
  exit;
}
$conexion->set_charset("utf8");

$stmt = $conexion->prepare("
  SELECT emisor_id, contenido, fecha 
  FROM mensajes 
  WHERE (emisor_id = ? AND receptor_id = ?) 
     OR (emisor_id = ? AND receptor_id = ?) 
  ORDER BY fecha ASC
");
$stmt->bind_param("iiii", $emisor_id, $receptor_id, $receptor_id, $emisor_id);
$stmt->execute();
$resultado = $stmt->get_result();

while ($fila = $resultado->fetch_assoc()) {
  $clase = ($fila["emisor_id"] == $emisor_id) ? "enviado" : "recibido";
  $autor = ($clase === "enviado") ? "Tú" : "Ellx";
  $contenido = htmlspecialchars($fila["contenido"]);
  $hora = date("H:i", strtotime($fila["fecha"]));
  echo "<div class='mensaje $clase'><strong>$autor:</strong> $contenido <span class='hora'>$hora</span></div>";
}

$stmt->close();
$conexion->close();
?>