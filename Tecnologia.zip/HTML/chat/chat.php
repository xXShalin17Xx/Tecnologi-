<?php
session_start();

$usuario_id = $_SESSION['id_usuario'] ?? null;
$receptor_id = isset($_GET['receptor_id']) ? intval($_GET['receptor_id']) : 0;

if (!$usuario_id || !$receptor_id) {
  echo "<div class='chat-error'>❌ Error: sesión no iniciada o receptor inválido.</div>";
  exit;
}

$conexion = new mysqli("localhost", "root", "", "tecnologia");
if ($conexion->connect_error) {
  echo "<div class='chat-error'>❌ Error de conexión a la base de datos.</div>";
  exit;
}
$conexion->set_charset("utf8");

$stmt = $conexion->prepare("
  SELECT emisor_id, contenido, fecha
  FROM mensajes
  WHERE (emisor_id = ? AND receptor_id = ?)
     OR (emisor_id = ? AND receptor_id = ?)
  ORDER BY fecha ASC
");

if (!$stmt) {
  echo "<div class='chat-error'>❌ Error en la consulta SQL: " . $conexion->error . "</div>";
  exit;
}

$stmt->bind_param("iiii", $usuario_id, $receptor_id, $receptor_id, $usuario_id);
$stmt->execute();
$resultado = $stmt->get_result();

$mensajesHTML = "";
while ($fila = $resultado->fetch_assoc()) {
  $clase = ($fila["emisor_id"] == $usuario_id) ? "mensaje-propio" : "mensaje-ajeno";
  $autor = ($clase === "mensaje-propio") ? "Tú" : "Ellx";
  $contenido = htmlspecialchars($fila["contenido"]);
  $hora = date("H:i", strtotime($fila["fecha"]));
  $mensajesHTML .= "<div class='$clase mensaje-nuevo'><strong>$autor:</strong> $contenido<span class='hora'>$hora</span></div>";
}

$stmt->close();
$conexion->close();
?>

<link rel="stylesheet" href="/HTML/chat/chat.css">

<div class="chat-panel-contenido">
  <form id="chat-form" class="chat-form">
    <input type="hidden" id="receptor-id" value="<?= $receptor_id ?>">
    <input type="text" id="chat-input" placeholder="Escribí tu mensaje..." autocomplete="off" />
    <button type="submit">Enviar</button>
  </form>

  <div id="chat-messages" class="chat-messages">
    <?= $mensajesHTML ?>
  </div>
</div>