<?php
session_start();
require_once $_SERVER['DOCUMENT_ROOT'] . "/HTML/inicio/config.php";

header("Content-Type: application/json");

if (!isset($_SESSION['id'])) {
  http_response_code(401);
  echo json_encode(["error" => "Sesión no válida"]);
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $message = isset($_POST['message']) ? trim($_POST['message']) : '';
  $receptorId = isset($_POST['receptor_id']) ? intval($_POST['receptor_id']) : 0;

  if ($message === '' || $receptorId <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Datos incompletos"]);
    exit;
  }

  $emisorId = $_SESSION['id'];

  $stmt = $conn->prepare("INSERT INTO mensajes (emisor_id, receptor_id, contenido, fecha) VALUES (?, ?, ?, NOW())");
  if ($stmt) {
    $stmt->bind_param("iis", $emisorId, $receptorId, $message);
    if ($stmt->execute()) {
      $respuesta = [
        'emisor' => 'Tú',
        'contenido' => htmlspecialchars($message),
        'hora' => date("H:i")
      ];
      echo json_encode($respuesta);
    } else {
      http_response_code(500);
      echo json_encode(["error" => "Error al guardar el mensaje"]);
    }
    $stmt->close();
  } else {
    http_response_code(500);
    echo json_encode(["error" => "Error en la preparación de la consulta"]);
  }
} else {
  http_response_code(405);
  echo json_encode(["error" => "Método no permitido"]);
}