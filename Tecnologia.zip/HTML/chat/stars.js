document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".rating-widget").forEach(widget => {
    const stars = widget.querySelectorAll(".star");
    const input = widget.closest("form")?.querySelector("input[name='val_estrella']");
    const idPubli = widget.dataset.id;
    let valorSeleccionado = 0;

    const aplicarRelleno = (valor) => {
      stars.forEach((star, i) => {
        const path = star.querySelector("path");
        const index = i + 1;
        star.classList.remove("llena", "media", "vacia");

        if (valor >= index) {
          star.classList.add("llena");
          path.setAttribute("fill", "gold");
        } else if (valor >= index - 0.5) {
          star.classList.add("media");
          path.setAttribute("fill", `url(#gradiente-mitad-${idPubli}-${index})`);
        } else {
          star.classList.add("vacia");
          path.setAttribute("fill", "#ccc");
        }
      });
    };

    stars.forEach((star, i) => {
      const index = i + 1;
      const path = star.querySelector("path");

      star.addEventListener("mousemove", (e) => {
        const mitad = e.offsetX < star.clientWidth / 2 ? 0.5 : 1;
        aplicarRelleno(index - 1 + mitad);
      });

      star.addEventListener("mouseleave", () => {
        aplicarRelleno(valorSeleccionado);
      });

      star.addEventListener("click", (e) => {
        const mitad = e.offsetX < star.clientWidth / 2 ? 0.5 : 1;
        valorSeleccionado = index - 1 + mitad;
        aplicarRelleno(valorSeleccionado);
        if (input) input.value = valorSeleccionado;
      });
    });

    const inicial = parseFloat(widget.dataset.rating);
    if (!isNaN(inicial) && inicial > 0) {
      valorSeleccionado = inicial;
      aplicarRelleno(valorSeleccionado);
      if (input) input.value = valorSeleccionado;
    }
  });
});