<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/../inicio/config.php";

if (!isset($_SESSION['id'])) {
    header("Location: ../login/index.php");
    exit();
}

$idUsuario = $_SESSION['id_usuario'];
$idPublicacion = $_POST['id_publicacion'] ?? '';
$valor         = floatval($_POST['val_estrella'] ?? 0);

// Validación básica
if ($idPublicacion === '' || $valor < 0.5 || $valor > 5.0) {
    die("Valoración inválida.");
}

// Insertar o actualizar valoración
$stmt = $conn->prepare("
    INSERT INTO calificaciones (id_usuario, id_publicacion, val_estrella)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE val_estrella = VALUES(val_estrella)
");
$stmt->bind_param("iid", $idUsuario, $idPublicacion, $valor);
$stmt->execute();
$stmt->close();

header("Location: ../inicio/home.php");
exit();