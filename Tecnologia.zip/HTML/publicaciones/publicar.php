<?php
session_start();
require_once __DIR__ . '/../inicio/config.php';

if (!isset($_SESSION['id_usuario'])) {
    die("Error: sesión no iniciada.");
}

$id_usuario = $_SESSION['id_usuario'];
$titulo     = $_POST['titulo'] ?? '';
$contenido  = $_POST['contenido'] ?? '';
$archivo    = $_FILES['imagen'] ?? null;

if (empty($titulo) || empty($contenido)) {
    die("Error: título o contenido vacío.");
}

$nombreArchivoFinal = null;

if ($archivo && $archivo['error'] === UPLOAD_ERR_OK) {
    function moverArchivo($archivo) {
        $nombre = uniqid() . '_' . basename($archivo['name']);
        $carpetaAbsoluta = realpath(__DIR__ . '/../inicio/uploads');

        if (!$carpetaAbsoluta || !is_dir($carpetaAbsoluta)) {
            throw new Exception("Carpeta de destino no encontrada.");
        }

        $rutaFinal = $carpetaAbsoluta . DIRECTORY_SEPARATOR . $nombre;

        if (!move_uploaded_file($archivo['tmp_name'], $rutaFinal)) {
            throw new Exception("No se pudo mover el archivo a '$rutaFinal'.");
        }

        return $nombre;
    }

    try {
        $nombreArchivoFinal = moverArchivo($archivo);
    } catch (Exception $e) {
        die("❌ Error al subir imagen: " . $e->getMessage());
    }
}

// Validar existencia de usuario
$stmt = $conn->prepare("SELECT COUNT(*) FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$stmt->bind_result($existe);
$stmt->fetch();
$stmt->close();

if ($existe == 0) {
    die("❌ Error: usuario no válido.");
}

// Insertar publicación
$stmt = $conn->prepare("
    INSERT INTO publicaciones (titulo, contenido, imagen_url, id_usuario)
    VALUES (?, ?, ?, ?)
");
$stmt->bind_param("sssi", $titulo, $contenido, $nombreArchivoFinal, $id_usuario);
$stmt->execute();
$stmt->close();

// Redirigir solo después de guardar
header("Location: ../inicio/home.php");
exit();
?>