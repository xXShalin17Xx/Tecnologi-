<?php
// Evita que errores se impriman como HTML
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

try {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (!isset($_SESSION['id'])) {
        throw new Exception("Sesión no iniciada");
    }

    $idUsuario = $_SESSION['id'];
    $nombreUsuario = $_SESSION['nombre'] ?? 'Usuario';

    $idPublicacion = $_POST['id_publicacion'] ?? null;
    $contenido = trim($_POST['contenido'] ?? '');

    if (!is_numeric($idPublicacion) || $contenido === '') {
        throw new Exception("Datos inválidos");
    }

    require_once '../../inicio/config.php';
    if (!isset($conn) || !$conn instanceof mysqli) {
        throw new Exception("Conexión no válida");
    }

    if (!isset($conn)) {
        throw new Exception("Conexión no establecida");
    }

    $stmt = $conn->prepare("INSERT INTO comentarios (autor_id, id_publicacion, contenido, fecha) VALUES (?, ?, ?, NOW())");
    if (!$stmt) {
        throw new Exception("Error al preparar la consulta: " . $conn->error);
    }

    $stmt->bind_param("iis", $idUsuario, $idPublicacion, $contenido);

    if (!$stmt->execute()) {
        throw new Exception("Error al guardar comentario: " . $stmt->error);
    }

    echo json_encode([
        "status" => "ok",
        "autor" => $nombreUsuario,
        "contenido" => $contenido,
        "fecha" => date("Y-m-d H:i:s")
    ]);
} catch (Exception $e) {
    error_log("Error en comentar.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "msg" => "Error interno: " . $e->getMessage()
    ]);
}