<?php
require_once $_SERVER['DOCUMENT_ROOT'] . "/HTML/inicio/config.php";

$idPubli = $idPublicacionActual ?? null;

if (!is_numeric($idPubli)) {
    echo "<p>Error: ID de publicación inválido.</p>";
    return;
}

$comentarios = $conn->query("
    SELECT c.contenido, u.nombre, c.fecha
      FROM comentarios c
      JOIN usuarios u ON c.autor_id = u.id
     WHERE c.id_publicacion = $idPubli
  ORDER BY c.fecha ASC
");

if ($comentarios && $comentarios->num_rows > 0) {
    while ($com = $comentarios->fetch_assoc()) {
        echo "<p><strong>" . htmlspecialchars($com['nombre']) . ":</strong> " .
             htmlspecialchars($com['contenido']) . " <em>(" . $com['fecha'] . ")</em></p>";
    }
} else {
    echo "<p>No hay comentarios aún.</p>";
}