<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/../inicio/config.php";

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../inicio/index.php");
    exit();
}

$nombreUsuario = $_SESSION['nombre'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Subir publicación - Los Ricky DS</title>
    <link rel="stylesheet" href="crear_publicacion.css">
</head>
<body>
    <div class="container-publicacion">
        <h2>Subir nueva publicación</h2>
        <p><strong>Autor:</strong> <?= htmlspecialchars($nombreUsuario) ?></p>

        <form class="form-publicacion" action="publicar.php" method="post" enctype="multipart/form-data">
            <label for="titulo">Título</label>
            <input type="text" id="titulo" name="titulo" placeholder="Título de la publicación" required>

            <label for="contenido">Contenido</label>
            <textarea id="contenido" name="contenido" placeholder="Escribe el contenido aquí..." required></textarea>

            <label for="imagen">Imagen (opcional)</label>
            <input type="file" id="imagen" name="imagen" accept="image/*">

            <button type="submit">📤 Publicar</button>
        </form>

        <div class="volver">
            <a href="../inicio/home.php">← Volver a publicaciones</a>
        </div>
    </div>
</body>
</html>