<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit();
}

// Registro de usuario
if (isset($_POST['register'])) {
    $nombre = $_POST['name'] ?? '';
    $apellido = $_POST['apellido'] ?? '';
    $email = $_POST['email'] ?? '';
    $passwordPlano = $_POST['contrasena'] ?? '';
    $password = password_hash($passwordPlano, PASSWORD_DEFAULT);

    if (empty($nombre) || empty($apellido) || empty($email) || empty($passwordPlano)) {
        $_SESSION['register_error'] = 'Completa todos los campos';
        $_SESSION['active_form'] = 'register';
        header("Location: index.php");
        exit();
    }

    $stmt = $conn->prepare("SELECT email FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $_SESSION['register_error'] = '¡Este email ya está registrado!';
        $_SESSION['active_form'] = 'register';
    } else {
        $stmtInsert = $conn->prepare("INSERT INTO usuarios (nombre, apellido, email, password) VALUES (?, ?, ?, ?)");
        $stmtInsert->bind_param("ssss", $nombre, $apellido, $email, $password);
        $stmtInsert->execute();
        $stmtInsert->close();
    }

    $stmt->close();
    header("Location: index.php");
    exit();
}

// Inicio de sesión
if (isset($_POST['login'])) {
    $email = $_POST['email'] ?? '';
    $password = $_POST['contrasena'] ?? '';

    $stmt = $conn->prepare("SELECT id, nombre, email, password, tipo FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $user = $resultado->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['id_usuario'] = $user['id']; // ← nombre estandarizado
            $_SESSION['email'] = $user['email'];
            $_SESSION['nombre'] = $user['nombre'];
            $_SESSION['rol'] = $user['tipo'];

            header("Location: ../inicio/home.php");
            exit();
        }
    }

    $_SESSION['login_error'] = 'Email o contraseña incorrectas';
    $_SESSION['active_form'] = 'login';
    header("Location: ../inicio/index.php");
    exit();
}
?>