<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);


$host     = "localhost";
$usuario  = "root";
$password = "";
$base     = "tecnologia";
$conn = new mysqli($host, $usuario, $password, $base);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("❌ Error de conexión a la base de datos: " . $conn->connect_error);
}
?>