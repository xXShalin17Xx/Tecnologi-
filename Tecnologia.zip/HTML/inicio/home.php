<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';

if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../inicio/index.php");
    exit();
}

$idUsuario = $_SESSION['id_usuario'];
$nombreUsuario = $_SESSION['nombre'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Publicaciones - Los Ricky DS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="/HTML/chat/chat.css">
    <style>
      #chat-panel {
        border-left: 1px solid #ccc;
        padding: 10px;
        width: 100%;
        max-width: 400px;
        position: fixed;
        top: 0;
        right: 0;
        height: 100%;
        background: #f9f9f9;
        overflow-y: auto;
        box-shadow: -2px 0 5px rgba(0,0,0,0.1);
        display: none;
      }
    </style>
</head>
<body>

<header>
  <div class="chat-acceso">
    <label for="selector-chat">💬 Abrir chat privado con:</label>
    <select id="selector-chat">
      <option value="">-- Seleccionar usuario --</option>
      <?php
      $usuarios = $conn->query("SELECT id, nombre FROM usuarios WHERE id != $idUsuario ORDER BY nombre ASC");
      while ($u = $usuarios->fetch_assoc()):
      ?>
        <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['nombre']) ?></option>
      <?php endwhile; ?>
    </select>
  </div>
</header>

<h1>Bienvenido, <?= htmlspecialchars($nombreUsuario) ?></h1>

<div id="chat-panel"></div>

<div class="crear-publicacion">
    <a href="../publicaciones/crear_publicacion.php">
        <button>📤 Subir publicación</button>
    </a>
</div>

<section>
    <h2>Publicaciones recientes</h2>
    <?php
    $query = $conn->query("
        SELECT p.id, p.titulo, p.contenido, p.imagen_url, p.fecha, u.nombre,
               (SELECT ROUND(AVG(val_estrella),1)
                  FROM calificaciones
                 WHERE id_publicacion = p.id) AS promedio
          FROM publicaciones p
          JOIN usuarios u ON p.id_usuario = u.id
      ORDER BY p.fecha DESC
    ");

    while ($publi = $query->fetch_assoc()) {
        $idPubli   = $publi['id'];
        $promedio  = $publi['promedio'] ?? 0;
        $redondeado = round($promedio * 2) / 2;
    ?>
    <div class="publicacion">
        <h3><?= htmlspecialchars($publi['titulo']) ?></h3>
        <p class="meta">
            <strong>Autor:</strong> <?= htmlspecialchars($publi['nombre']) ?> |
            <strong>Fecha:</strong> <?= $publi['fecha'] ?>
        </p>
        <p class="contenido"><?= nl2br(htmlspecialchars($publi['contenido'])) ?></p>
        <?php if (!empty($publi['imagen_url'])): ?>
            <img src="uploads/<?= htmlspecialchars($publi['imagen_url']) ?>"
            alt="Imagen"
            class="foto-publicacion"
            onerror="this.src='default.jpg'; this.classList.add('imagen-fallback');">
        <?php endif; ?>

        <p class="promedio">
            <strong class="valoracionProm">Valoración promedio:</strong>
            <?php
            $enteras = floor($redondeado);
            $media   = ($redondeado - $enteras) >= 0.5;
            for ($i = 1; $i <= 5; $i++) {
                if ($i <= $enteras) {
                    echo "<span class='estrella-promedio llena'></span>";
                } elseif ($i == $enteras + 1 && $media) {
                    echo "<span class='estrella-promedio media'></span>";
                } else {
                    echo "<span class='estrella-promedio'></span>";
                }
            }
            ?>
            (<?= $redondeado ?> ⭐)
        </p>

        <?php
        $yaValoro = $conn->query("
            SELECT val_estrella
              FROM calificaciones
             WHERE id_publicacion = $idPubli
               AND id_usuario    = $idUsuario
        ")->fetch_assoc();
        ?>

        <?php if ($yaValoro): ?>
            <p class="tu-valor">
                <strong>Tu valoración:</strong> <?= $yaValoro['val_estrella'] ?> ⭐
            </p>
        <?php else: ?>
    <form action="../chat/valorar.php" method="post" class="rating-form">
        <input type="hidden" name="id_publicacion" value="<?= $idPubli ?>">
        <input type="hidden" name="val_estrella" id="rating-input-<?= $idPubli ?>" value="0">

        <div class="rating-widget" data-id="<?= $idPubli ?>" data-rating="0">
            <?php for ($i = 1; $i <= 5; $i++): ?>
            <svg class="star" data-index="<?= $i ?>" viewBox="0 0 24 24" width="32" height="32">
                <defs>
                    <linearGradient id="gradiente-mitad-<?= $idPubli ?>-<?= $i ?>" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="50%" stop-color="gold"/>
                        <stop offset="50%" stop-color="#ccc"/>
                    </linearGradient>
                </defs>
                <path d="M12 17.3L6.2 21l1.1-6.4L2 9.8l6.4-.9L12 3l2.6 5.9 6.4.9-4.6 4.8 1.1 6.4z"/>
            </svg>
            <?php endfor; ?>
        </div>

        <button type="submit">Valorar</button>
    </form>
    <?php endif; ?>
                <div class="comentarios" data-id="<?= $idPubli ?>">
              <h4>Comentarios:</h4>
              <div class="comentarios-lista">
                <?php
                    $idPublicacionActual = $idPubli;
                    include "../publicaciones/comentarios/render_comentarios.php";
                ?>
              </div>
            </div>

            <form action="../publicaciones/comentarios/comentar.php" method="post" class="comment-form">
                <input type="hidden" name="id_publicacion" value="<?= $idPubli ?>">
                <textarea name="contenido" placeholder="Escribe un comentario..." required></textarea>
                <button type="submit">Comentar</button>
            </form>
        </div>
        <hr>
        <?php } ?>
    </section>

    <script src="../chat/stars.js" defer></script>
    <script>
    document.getElementById('selector-chat').addEventListener('change', function () {
      const receptorId = this.value;
      const panel = document.getElementById('chat-panel');

      if (!receptorId) {
        panel.innerHTML = '';
        panel.style.display = 'none';
        return;
      }

      fetch(`/HTML/chat/chat.php?receptor_id=${receptorId}`)
        .then(res => res.text())
        .then(html => {
          panel.innerHTML = html;
          panel.style.display = 'block';

          const script = document.createElement("script");
          script.src = "/HTML/chat/chat.js";
          script.onload = () => {
            if (typeof iniciarChat === "function") iniciarChat();
          };
          document.body.appendChild(script);
        })
        .catch(err => {
          panel.innerHTML = "<p>Error al cargar el chat.</p>";
          console.error(err);
        });
    });
    </script>

    <script src="/HTML/chat/chat.js" defer></script>
    <script>
    document.querySelectorAll('.comment-form').forEach(form => {
      form.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(this);
        const btn = this.querySelector('button');
        btn.disabled = true;

        fetch('../publicaciones/comentarios/comentar.php', {
          method: 'POST',
          body: formData,
          credentials: 'include' // ✅ Esto permite que se envíe la cookie de sesión
        })
        .then(res => res.json())
        .then(data => {
          console.log("Respuesta JSON:", data);
          if (data.status === "ok") {
            const comentario = document.createElement('p');
            comentario.innerHTML = `<strong>${data.autor}:</strong> ${data.contenido} <em>(${data.fecha})</em>`;
            this.previousElementSibling.querySelector('.comentarios-lista').appendChild(comentario);
            this.querySelector('textarea').value = '';
          } else {
            alert("Error al comentar: " + data.msg);
          }
        })
        .catch(err => {
          console.error("Error de red:", err);
          alert("Error de red al comentar.");
        })
        .finally(() => {
          btn.disabled = false;
        });
      });
    });
    </script>
</body>
</html>