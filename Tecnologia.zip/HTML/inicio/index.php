<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

$errors = [
    'login' => $_SESSION['login_error'] ?? '',
    'register' => $_SESSION['register_error'] ?? ''
];

$activeForm = $_SESSION['active_form'] ?? 'login';

unset($_SESSION['login_error'], $_SESSION['register_error'], $_SESSION['active_form']);


function showError($error) {
    return empty($error) ? "" : "<p class='error-mensaje'>$error</p>";
}

function isActiveForm($formName, $activeForm) {
    return $formName === $activeForm ? 'active' : "";
}
if (isset($_SESSION['id_usuario'])) {
    echo "<p class='bienvenida'>Bienvenido, " . htmlspecialchars($_SESSION['nombre']) . "</p>";
}
?>
    
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>inicio de sesion</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="logo">
        <div class="icon"></div>
            LOS RICKY DS
        <span class="corp">Corp</span>
    </div>


    <div class="contenido">

        <div class="form-box <?= isActiveForm('login', $activeForm); ?>" id="login-form">
            <form action="login_register.php" method="post" >
                <h2>Inico de Sesión</h2>
                <?= showError($errors['login']); ?>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="contrasena" placeholder="Contraseña" required>
                <button type="submit" name="login">Iniciar Sesion</button>
                <p>¿No tienes una cuenta? <a href="#" onclick="showForm('register-form')">Registrarse</a></p>
            </form>
        </div>
        
        <div class="form-box <?= isActiveForm('register', $activeForm); ?>" id="register-form">
            <form action="login_register.php" method="post">
                <h2>Registro</h2>
                <?= showError($errors['register']); ?>
                <input type="text" name="name" placeholder="Nombre" required>
                <input type="text" name="apellido" placeholder="Apellido" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="contrasena" placeholder="Contraseña" required>
                <button type="submit" name="register">Registrarse</button>
                <p>¿Ya tienes una cuenta? <a href="#" onclick="showForm('login-form')">Iniciar Sesion</a></p>
            </form>
        </div>
    </div>
    <button id="theme-toggle" title="Cambiar tema">🌙</button>

    <script src="script.js"></script>
</body>
</html>